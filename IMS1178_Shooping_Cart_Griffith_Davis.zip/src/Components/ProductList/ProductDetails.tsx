import { useContext } from "react";
import { ProductContext } from "../Context/ProductContext";
import { ProductType } from "../Types/ProductType";
type Demo={
    selected:ProductType  
}
const ProductDetails: React.FC<Demo> = (props) => {

const {selected}=props;
    const prodDetails = useContext(ProductContext)

    const details = (prod: ProductType) =>{
        prodDetails?.detail(prod)
    }

    return(
        <div className="details">
            {/* {Products.map((product) => {
                return(
                    <div>
                        <h1>{product.name}</h1>
                        <p>{product.description}</p>
                        <p>${product.price}</p>
                        <p>Quantity: {product.quantity}</p>
                    </div>
                )
            })} */}
            Name: {selected.name}
            <br />
            Description: {selected.description}
            <br />
            Price: {selected.price}
            <br />
            Quantity: {selected.quantity}
            <br />
            <button onClick={addToCart}>Add to Cart</button>
        </div>
    )

}

export default ProductDetails;