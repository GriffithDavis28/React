import React, { useContext } from "react";
import { ProductContext } from "../Context/ProductContext";
import { ProductType } from "../Types/ProductType";
import { Products } from "./Products";
import './ProductsList.scss';

const ProductList: React.FC = () => {

    const p = useContext(ProductContext);

    const showDetails = (prod: ProductType) => {
        p?.detail(prod)
    }

    const addToCart = (prod: ProductType) => {
        p?.product
    }   

  return (
      <div className="products-list">
        {Products.map((prod) => {
          return (
            <div className="products"> 
                <h1>{prod.name}</h1>
                <p>{prod.price}</p>
                <button onClick={() => showDetails(prod)}>details</button>
                <button onClick={addToCart}>Add to Cart</button>
            </div>
          );
        })}
      </div>
  );
};

export default ProductList;
