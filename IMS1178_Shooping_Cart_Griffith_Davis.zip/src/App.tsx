import { useState } from 'react';
import './App.scss';
import Cart from './Components/Cart/Cart';
import { ProductContext } from './Components/Context/ProductContext';
import ProductDetails from './Components/ProductList/ProductDetails';
import { Products } from './Components/ProductList/Products';
import ProductList from './Components/ProductList/ProductsList';
import { ProductType } from './Components/Types/ProductType';

function App() {
  const [selectedProduct, setSelectedProduct] = useState<ProductType>();
  const [condition, setCondition] = useState<boolean>(false);

  
  const detail = (prod: ProductType) => {
    setSelectedProduct(prod);
  };

  return (
    <div className="App">
      <div>
        <h1>Dashboard</h1>
      </div>
      <div>
        <ProductContext.Provider value={{ product: Products, detail }}>
          <ProductList />
          {selectedProduct && <ProductDetails selected={selectedProduct} />}
        </ProductContext.Provider>
      </div>
      <div>
        <Cart />
      </div>
    </div>
  );
}

export default App;