import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";
import { Link, Route, Switch } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import "./App.scss";
import Cart from "./Components/Cart/Cart";
import { ProductContext } from "./Components/Context/ProductContext";
import Dashboard from "./Components/Dashboard/Dasbaord";
import Header from "./Components/Header/Header";
import Orders from "./Components/Orders/Orders";
import ProductDetails from "./Components/ProductList/ProductDetails";
import { Products } from "./Components/ProductList/Products";
import ProductList from "./Components/ProductList/ProductsList";
import { ProductType } from "./Components/Types/ProductType";
import UsersList from "./Components/Users/UsersList";


export interface cartObject extends ProductType {
  quantity: number;
}

export interface orderObject {
  id: string;
  username: string;
  totalPrice: number;
  quantity: number;
  city: string;
}

function App() {
  const [selectedProduct, setSelectedProduct] = useState<ProductType>();
  const [condition, setCondition] = useState<boolean>(false);

  const [cartItems, setCartItems] = useState<cartObject[]>([]);
  const [orderItems, setOrderItems] = useState<orderObject[]>([]);

  const addToCart = (prod: ProductType) => {
    let find: boolean = false;

    const newarray: cartObject[] = cartItems.map((item) => {
      if (item.id === prod.id) {
        find = true;
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });

    if (find === false) {
      newarray.push({ ...prod, quantity: 1 });
    }

    setCartItems([...newarray]);
  };

  const handleIncrement = (prod: cartObject) => {
    const newarray: cartObject[] = cartItems.map((item) => {
      if (item.id === prod.id) {
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });

    setCartItems([...newarray]);
  };

  const handleDecrement = (prod: cartObject) => {
    if (prod.quantity > 1) {
      const newArray: cartObject[] = cartItems.map((item) => {
        if (item.id === prod.id) {
          return { ...item, quantity: item.quantity - 1 };
        }
        return item;
      });
      setCartItems([...newArray]);
    }
  };

  const detail = (prod: ProductType) => {
    setSelectedProduct(prod);
  };

  const placeOrder = (value: number, city: string, username: string) => {

    const id = (uuidv4());
    const quantity = cartItems.reduce((total, item) => total + item.quantity, 0);
    console.log(id)

    setOrderItems([
      ...orderItems,
      { id: id, totalPrice: value, city: "something", quantity: 1, username: "some name"},
    ]);
  };

  return (
    <div className="App">
      <div className="Header">
        <Header />
      </div>
      <div className="sidebar">
        <Link to="/cart"><button>Go to cart</button></Link>
        <Link to="/dashboard">Dashboard</Link>
        <Link to="/users">Users</Link>
        <Link to="/products"> Products</Link>
        <Link to="/cart">Cart</Link>
        <Link to="/orders">Orders</Link>
      </div>

      <div className="Content">
        <ProductContext.Provider value={{ product: Products, detail }}>
          <Switch>
            <Route path={"/dashboard"} exact={true}>
              <Dashboard  />
            </Route>
            <Route path={"/users"} exact={true}>
              <UsersList />
            </Route>
            <Route path={"/products"} exact={true}>
              <ProductList addToCart={addToCart} />
              {selectedProduct && <ProductDetails selected={selectedProduct} />}
            </Route>
            <Route path={"/cart"} exact={true}>
              <Cart
                cartItems={cartItems}
                handleIncrement={handleIncrement}
                handleDecrement={handleDecrement}
                placeOrder={placeOrder}
              />
            </Route>
            <Route path={"/orders"} exact={true}>
              <Orders orders={orderItems} />
            </Route>
          </Switch>
        </ProductContext.Provider>
      </div>
    </div>
  );
}

export default App;


