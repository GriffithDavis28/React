import React from 'react';
import { useLocation } from 'react-router-dom';

const Header: React.FC = () =>{

    const location = useLocation();

    const getPageName = () => {
        switch(location.pathname){
            case "/dashboard":
                return "Dashboard";
            case "/products":
                return "Products";
            case "/cart":
                return "Cart";
            case "/orders":
                return "Orders";
            default:
                return "Dashboard";
        }
    }

  return (
    <div>{getPageName()}</div>
  )
}

export default Header;
