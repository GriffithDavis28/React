import { useEffect, useState } from 'react';
import { cartObject } from '../../App';
import { ProductType } from '../Types/ProductType';
import User from '../Users/Users';
import './Cart.scss';

type cartProps ={
  cartItems: ProductType[];
  handleIncrement:(prod:cartObject)=>void;
  handleDecrement: (prod: cartObject) => void;
  placeOrder:(number1:number, city: string, username: string)=>void;
}

type User = typeof User[number];
type Address = typeof User[number]['address'][number];

const Cart = ({cartItems, handleIncrement, handleDecrement,placeOrder}: cartProps) => {

  const [totalvalue1,setTotalvalue]=useState<number>(0);
  const [selectedUser, setSelectedUser] = useState<User | null | undefined>(null);
  const [totalQuantity, setTotalQuantity] = useState<number>(0);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null)

  useEffect(()=>{
    let totalvalue=0;
    let totalQuantity=0;
    cartItems.map((items)=>{
      totalvalue=items.price*items.quantity
      totalQuantity+=items.quantity
    })
    setTotalvalue(totalvalue);
    setTotalQuantity(totalQuantity)
  },[cartItems])


  const selectUser = (e:React.ChangeEvent<HTMLSelectElement>) => {
    const selectedUserId = parseInt(e.target.value);
    const selectedUserObj = User.find((user) => user.id === selectedUserId);
    setSelectedUser(selectedUserObj);
  }

  const selectAddress = (e: React.ChangeEvent<HTMLSelectElement>) => {
     const selectedAddressId = parseInt(e.target.value);
     if(selectedUser && selectedUser.address[selectedAddressId])
     {
      setSelectedAddress(selectedUser.address[selectedAddressId])
     }
     else
     setSelectedAddress(null);
  }

  const orderPlaced = () =>{
    console.log("order placed")
    if( selectedUser && selectedAddress)
    {
      console.log(selectedUser, selectAddress)
        placeOrder(totalvalue1, selectedAddress.address, selectedUser.name)
    }
  }

  return (
    <div className="cart-container">
      <h2>Shopping Cart</h2>
      <ul>
        {/* {cartItems.map((item, index) => (
          <li key={index}>
            {item.name} - ${item.price}
          </li>
        ))} */}
       {cartItems.map((eachItem) => {
        return(
          <div className='display-items'>
            <p>{eachItem.name}</p>
            <p>{eachItem.price}</p>
            <p>{eachItem.quantity}</p>
            <button onClick={()=>handleIncrement(eachItem)}>+</button>
            <button onClick={() => handleDecrement(eachItem)}>-</button>
          </div>
        )
       })}
      </ul>
      <div className='place-order-btn'>
        <button onClick={orderPlaced}>Place order</button>
      </div>
      Total Price: <p>{totalvalue1}</p>

      <div className='user-cart'>
        <div>
            <select onChange={(e) => selectUser(e)}>
              Select a user
            {User.map((user,index) => (
              <option key={user.id} value={user.id}>{user.name}</option>
            )) }
            </select>

            {selectedUser && (
              <select onChange={(e) => selectAddress(e)}>
                {selectedUser.address.map((address, index) => (
                  <option key={index} value={index}>
                    {address.address}
                  </option>
                ))}
              </select>
            )}
        </div>
        <div>
        </div>
      </div>
    </div>
  );
};

export default Cart;