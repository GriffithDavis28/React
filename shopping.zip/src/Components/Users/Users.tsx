import { Users } from "../Types/UserType";

const User: Users[] = [
  {
    id: 1,
    name: "John",
    address: [{ address: "401 1st street", city: "Seattle" }],
  },
  {
    id: 2,
    name: "James",
    address: [{ address:"305 Bedrock circle", city:"Baltimore"}],
  },
  {
    id: 3,
    name: "Rachel",
    address: [{address:"1209 St. John's drive", city:"Washington D.C."}],
  },
  {
    id: 4,
    name: "Lisa",
    address: [{address:"121 Beverly Hill", city:"California"}],
  },
  {
    id: 5,
    name: "Random",
    address: [{address:"44th Silverspoon", city:"Minnesota"}],
  },
];

export default User;
