import React from "react";
import User from "./Users";
import "./UsersList.scss";

const UsersList: React.FC<any> = () => {
    return(
        <div className="Users-list">
            {User.map((eachUser) => {
                return(
                    <div className="users" key={eachUser.id}>
                        <h1>{eachUser.id}. {eachUser.name}</h1>
                    </div>
                );
            })}
        </div>
    )
}
export default UsersList;



