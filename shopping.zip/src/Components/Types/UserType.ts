export type Users = { 
    id: number;
    name: string;
    address: AddType[];
}

export type AddType = {
    address: string,
    city: string
}