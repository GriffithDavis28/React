import { useContext } from "react";
import { ProductContext } from "../Context/ProductContext";
import { ProductType } from "../Types/ProductType";
import './display.scss';

type Demo={
    selected:ProductType  
}
const ProductDetails: React.FC<Demo> = (props) => {

const {selected}=props;
    const prodDetails = useContext(ProductContext)

    const details = (prod: ProductType) =>{
        prodDetails?.detail(prod)
    }

    return(
        <div className="details">
            <h1> Name: {selected.name} </h1>
            <br />
            <p>Description: {selected.description}</p>
            <br />
            <p>Price: {selected.price}</p>
            <br />
            <p>Quantity: {selected.quantity}</p>
            <br />
        </div>
    )
}

export default ProductDetails;