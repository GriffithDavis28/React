import React from "react";
import DataTable from "react-data-table-component";
import { orderObject } from "../../App";

interface OrderProp {
  orders: orderObject[];
}

const Orders: React.FC<OrderProp> = ({ orders }) => {

  const columns = [
    {
      name: "OrderID",
      selector: (row: orderObject) => row.id,
    },
    {
      name: "Username",
      selector: (row: orderObject) => row.username
    },
    {
      name: "Total Amount",
      selector: (row: orderObject) => row.totalPrice
    },
    {
      name: "Quantity",
      selector: (row: orderObject) => row.quantity
    },
    {
      name: "City",
      selector: (row: orderObject) => row.city
    }
  ]


  return (
    <div>
      <DataTable
            columns={columns}
            data={orders}
      />
    </div>
  );
};
export default Orders;
