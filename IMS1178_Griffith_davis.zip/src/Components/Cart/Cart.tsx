import { useEffect, useState } from 'react';
import { cartobject } from '../../App';
import { ProductType } from '../Types/ProductType';
import './Cart.scss';

type cartProps ={
  cartItems: ProductType[];
  handleIncrement:(prod:cartobject)=>void;
  handleDecrement: (prod: cartobject) => void;
  placeOrder:(number1:number)=>void;
}

const Cart = ({cartItems, handleIncrement, handleDecrement,placeOrder}: cartProps) => {
  // State to maintain the list of products in the cart
  

  // Function to add a product to the cart
  // const addToCart = (product: ProductType) => {
  //   setCartItems([...cartItems, product]);
  // };

  const [totalvalue1,setTotalvalue]=useState<number>(0);

  useEffect(()=>{
    let totalvalue=0;
    cartItems.map((items)=>{
      totalvalue=items.price*items.quantity
    })
    setTotalvalue(totalvalue);
  },[cartItems])

  return (
    <div className="cart">
      <h2>Shopping Cart</h2>
      <p>{totalvalue1}</p>
      <ul>
        {/* {cartItems.map((item, index) => (
          <li key={index}>
            {item.name} - ${item.price}
          </li>
        ))} */}
       {cartItems.map((eachItem) => {
        return(
          <div>
            <p>{eachItem.name}</p>
            <p>{eachItem.price}</p>
            <p>{eachItem.quantity}</p>
            <button onClick={()=>handleIncrement(eachItem)}>+</button>
            <button onClick={() => handleDecrement(eachItem)}>-</button>
          </div>
        )
       })}
      </ul>
      <div>
        <button onClick={()=>placeOrder(totalvalue1)}>Place order</button>
      </div>
      
    </div>
  );
};

export default Cart;


