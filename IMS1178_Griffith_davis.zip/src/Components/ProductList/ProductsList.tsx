import React, { useContext, useState } from "react";
import { ProductContext } from "../Context/ProductContext";
import { ProductType } from "../Types/ProductType";
import { Products } from "./Products";
import './ProductsList.scss';

type ProductListProps = {
  addToCart: (product: ProductType) => void
}

const ProductList: React.FC<ProductListProps> = ({addToCart}) => {

    const p = useContext(ProductContext);

    const [cart, setCart] = useState<ProductType[]>([]);

    const showDetails = (prod: ProductType) => {
        p?.detail(prod)
    }


  return (
      <div className="products-list">
        {Products.map((prod) => {
          return (
            <div className="products" key={prod.id}> 
                <h1>{prod.name}</h1>
                <p>{prod.price}</p>
                <button onClick={() => showDetails(prod)}>details</button>
                <button onClick={() => addToCart(prod)}>Add to Cart</button>
            </div>
          );
        })}
      </div>
  );
};

export default ProductList;