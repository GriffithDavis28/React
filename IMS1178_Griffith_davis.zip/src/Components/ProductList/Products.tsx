import { ProductType } from "../Types/ProductType";

const Products: ProductType[] = [
  {
    id: 1,
    name: "Helmet",
    description: "Certified and provides Grade a Protection",
    price: 8000.00,
    quantity: 4,
  },
  {
    id: 2,
    name: "Rolex",
    description: "Crown yourself like a king",
    price: 40000.00,
    quantity: 3,
  },
  {
    id:3,
    name:"Microsoft Surface",
    description:"Powered by the latest intel processor",
    price:35000.00,
    quantity:6
  }
];

export { Products };
