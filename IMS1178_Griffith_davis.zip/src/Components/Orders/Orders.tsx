import React from "react";
import { orderobject } from "../../App";

interface OrderProp {
  orders: orderobject[];
}

const Orders: React.FC<OrderProp> = ({ orders }) => {
  return (
    <div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">total Price</th>
          </tr>
        </thead>
        <tbody>
            {
                orders.map((items)=>(
                    <tr>
                    <th scope="row">{items.id}</th>
                    <td>{items.totalprice}</td>
                  </tr>
                ))
            }
          
        </tbody>
      </table>
    </div>
  );
};
export default Orders;
