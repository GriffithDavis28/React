import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from "react";
import "./App.scss";
import Cart from "./Components/Cart/Cart";
import { ProductContext } from "./Components/Context/ProductContext";
import Orders from "./Components/Orders/Orders";
import ProductDetails from "./Components/ProductList/ProductDetails";
import { Products } from "./Components/ProductList/Products";
import ProductList from "./Components/ProductList/ProductsList";
import { ProductType } from "./Components/Types/ProductType";

export interface cartobject extends ProductType {
  quantity: number;
}

export interface orderobject{
  id:number;
  totalprice:number;
}

function App() {
  const [selectedProduct, setSelectedProduct] = useState<ProductType>();
  const [condition, setCondition] = useState<boolean>(false);

  const [cartItems, setCartItems] = useState<cartobject[]>([]);
  const [orderItems,setOrderItems]=useState<orderobject[]>([]);

  const addToCart = (prod: ProductType) => {
    let find: boolean = false;

    const newarray: cartobject[] = cartItems.map((item) => {
      if (item.id === prod.id) {
        find = true;
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });

    if (find === false) {
      newarray.push({ ...prod, quantity: 1 });
    }

    setCartItems([...newarray]);
  };

  const handleIncrement = (prod:cartobject) => {

    const newarray:cartobject[]=cartItems.map((item)=>{
      if(item.id===prod.id){
        return {...item,quantity:item.quantity+1}
      }
      return item;
    })

    setCartItems([...newarray]);

  }

  const handleDecrement = (prod:cartobject) => {

    const newArray: cartobject[] = cartItems.map((item) => {

      if(item.id === prod.id)
      {
        return{...item, quantity: item.quantity-1}
      }
      return item
    })

    setCartItems([...newArray])
  }

  console.log(cartItems);

  const detail = (prod: ProductType) => {
    setSelectedProduct(prod);
  };


  const placeOrder = (value:number) => {
    setOrderItems([...orderItems,{id:orderItems.length+1,totalprice:value}]);


  }

  return (
    <div className="App">
      <div className="Product-container">
        <ProductContext.Provider value={{ product: Products, detail }}>
          <ProductList addToCart={addToCart} />
          {selectedProduct && <ProductDetails selected={selectedProduct} />}
          <Cart cartItems={cartItems} handleIncrement={handleIncrement} handleDecrement={handleDecrement} placeOrder={placeOrder}/>
        </ProductContext.Provider>
      </div>
      <Orders orders={orderItems}/>
    </div>
  );
}

export default App;
